#ifndef DECOD
#define DECOD

typedef struct{
    char stego_img_in_fname[16];
    FILE * fptr_stego;
}DecodeInfo ;

Status read_and_validate_decode_args(char *argv[], DecodeInfo * decInfo);

Status do_decoding(DecodeInfo * decInfo);

void decode_data_from_image(char * data, int size, DecodeInfo * decInfo );

char decode_byte_from_lsb(char *buff );


#endif