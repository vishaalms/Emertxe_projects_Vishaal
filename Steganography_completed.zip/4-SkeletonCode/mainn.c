#include <stdio.h>
#include "encode.h"
#include "types.h"
#include "common.h"
#include <stdio_ext.h>
#include "decode.h"


int main(int argc ,    char * argv[]  )
{
    

    OperationType optype = check_operation_type(argv);

    if(optype ==  e_encode){
        EncodeInfo encinf ;
        Status st = read_and_validate_encode_args(argv , &encinf );
        if(st == e_failure){printf("\nPlease type in correct format\nFor Encoding : $ ./a.out -e beautiful.bmp secrect.txt [stego.bmp(optional)]\nFor Decoding : $ ./a.out -d stego.bmp [secretout.txt(optional)]\n\n");}  
        else{
            printf("\nYou have Selected Encode Option\n");
            Status st2 = do_encoding(&encinf);
            if(st2 == e_failure)  printf("\nEncoding Failed\n");
            else  printf("\nEncoding Completed Successfully\n");
        }
        
    }
    else if(optype ==   e_decode ){
        DecodeInfo decinf;
        Status st = read_and_validate_decode_args(argv ,  &decinf );
        if(st == e_failure)
        printf("\nPlease type in correct format\nFor Encoding : $ ./a.out -e beautiful.bmp secrect.txt [stego.bmp(optional)]\nFor Decoding : $ ./a.out -d stego.bmp [secretout.txt(optional)]\n\n");
        else{
            printf("\nYou have Selected Decode Option\n");
            Status st2 = do_decoding(&decinf);
            if(st2 == e_failure)  printf("\nDecoding Failed\n");
            else  printf("\nDecoding Completed Successfully\n");
        }

    }
    else{
        printf("\nUnsupported Operation!\n");
        printf("For Encoding : $ ./a.out -e beautiful.bmp secrect.txt [stego.bmp(optional)]\n");
        printf("For Decoding : $ ./a.out -d stego.bmp [secretout.txt(optional)]\n\n");
    }

    return 0;
}
