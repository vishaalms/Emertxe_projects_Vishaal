#include <stdio.h>754
#include "encode.h"
#include "types.h"
#include "common.h"
#include <stdio_ext.h>
#include "decode.h"
#include <string.h>

Status read_and_validate_decode_args(char *argv[], DecodeInfo * decInfo){
    if(argv[2] ==  NULL)   return e_failure;

    else if(strstr(argv[2] , ".bmp") ){
        strcpy(  (decInfo -> stego_img_in_fname)  , argv[2]  );     
    }
    else{
        return e_failure;
    }

    
    
    return e_success;
}

Status do_decoding(DecodeInfo * decInfo){

    decInfo->fptr_stego = fopen(decInfo->stego_img_in_fname , "r");
    if (decInfo->fptr_stego == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->stego_img_in_fname );

    	return e_failure;
    }

    
    printf("\nFiles opened Successfully\n");

    fseek(decInfo->fptr_stego ,  54  ,   SEEK_SET );
    
    char magic_string[3];    magic_string[2] = 0 ;
    decode_data_from_image(magic_string ,  2  ,   decInfo );
    
    if(strcmp(MAGIC_STRING , magic_string  ) == 0 ){
        printf("Magic String is Matching\n");
    }  
    else {
        printf("Magic String not matching!!\n");
        return e_failure;
    }

    int file_extn_size;
    decode_data_from_image(&file_extn_size , 4 , decInfo);

    char file_extn[file_extn_size + 1];
    file_extn[file_extn_size] =  0;
    decode_data_from_image(file_extn , file_extn_size , decInfo);

    char out_fname[21] = "secretout" ;
    strcat(out_fname , file_extn);

    FILE * fptr_out = fopen( out_fname  ,  "w+"  );

    uint file_size;
    decode_data_from_image(&file_size , 4 , decInfo);

    char secret[file_size + 1];
    secret[file_size] = 0;
    decode_data_from_image(secret , file_size  , decInfo);

    fprintf(fptr_out  ,   "%s"   ,    secret   );

    printf("Contents added to secretout file Successfully\n");

    fclose(fptr_out);
    fclose(decInfo->fptr_stego);

    return e_success;
}

void decode_data_from_image(char * data, int size, DecodeInfo * decInfo ){
    for(int i =0 ; i< size ; i++){
        char buff[8];
        fread(buff , 8 , 1 ,  decInfo->fptr_stego );
        data[i] = decode_byte_from_lsb(  buff  );
    }
}



char decode_byte_from_lsb(char *buff ){

    char returner =  0b00000000 ;
    unsigned char te = 0b10000000;

    for(int i=0; i<8 ; i++){
        if( (buff[i] & 1)  == 1   ){
            returner =  returner | te;
        }
        te = te >> 1;
    }

    return returner;
}