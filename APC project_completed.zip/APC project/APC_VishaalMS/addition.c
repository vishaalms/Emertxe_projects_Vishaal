#include "apc.h"

int addition(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR)
{
    int carry = 0;
    Dlist *t1 = *tail1;
    Dlist *t2 = *tail2;

    while (t1 || t2)
    {
        int sum = (t1 ? t1->data : 0) + (t2 ? t2->data : 0) + carry;
        carry = sum / 10;
        dl_insert_first(headR, tailR, sum % 10);
        if (t1) t1 = t1->prev;
        if (t2) t2 = t2->prev;
    }

    if (carry) dl_insert_first(headR, tailR, carry);

    return SUCCESS;
}