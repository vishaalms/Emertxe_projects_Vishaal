#include"apc.h"





void reverseDLL(Dlist **head, Dlist **tail) {
    Dlist *temp = NULL;
    Dlist *current = *head;
    
    while (current != NULL) {
        temp = current->prev;
        current->prev = current->next;
        current->next = temp;
        current = current->prev;
    }

    if (temp != NULL) {
        *head = temp->prev;  // Update head to the new front
    }

    *tail = *head;
    while ((*tail)->next != NULL) {
        *tail = (*tail)->next;  // Update tail to the new end
    }
}

int multiplication(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR) {
    if (*head1 == NULL || *head2 == NULL) return FAILURE ; 

    // Get the lengths of the two numbers
    int len1 = 0, len2 = 0;
    for (Dlist *temp = *head1; temp != NULL; temp = temp->next) len1++;
    for (Dlist *temp = *head2; temp != NULL; temp = temp->next) len2++;

    // Initialize result DLL with zeros (len1 + len2 digits at most)
    Dlist *res[len1 + len2]; // Array to store references to result nodes
    for (int i = 0; i < len1 + len2; i++) {
        res[i] = (Dlist *)malloc(sizeof(Dlist));
        res[i]->data = 0;
        res[i]->prev = (i == 0) ? NULL : res[i - 1];
        res[i]->next = NULL;
        if (i > 0) res[i - 1]->next = res[i];
    }
    *headR = res[0];
    *tailR = res[len1 + len2 - 1];

    
    Dlist *ptr2 = *tail2;
    int pos2 = 0;
    
    while (ptr2) {
        int carry = 0;
        int pos1 = 0;
        Dlist *ptr1 = *tail1;
        Dlist *resPtr = res[pos2]; // Start adding from this position

        while (ptr1) {
            int mul = ptr2->data * ptr1->data + resPtr->data + carry;
            resPtr->data = mul % 10;
            carry = mul / 10;

            ptr1 = ptr1->prev;
            resPtr = resPtr->next;
            pos1++;
        }

        if (carry > 0) {
            resPtr->data += carry;
        }

        ptr2 = ptr2->prev;
        pos2++;
    }

    

    // Reverse the result DLL to print in correct order
    reverseDLL(headR, tailR);

    // Remove leading zeros in the result DLL
    while ((*headR)->data == 0 && (*headR)->next != NULL) {
        *headR = (*headR)->next;
        free((*headR)->prev);
        (*headR)->prev = NULL;
    }
}
