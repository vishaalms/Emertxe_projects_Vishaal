#include "apc.h"

int main(int argc, char *argv[])
{
    Dlist *head1 = NULL, *tail1 = NULL;
    Dlist *head2 = NULL, *tail2 = NULL;
    Dlist *headR = NULL, *tailR = NULL;

    if (argc != 4)
    {
        printf("Usage: <operand1> <operator> <operand2>\n");
        return FAILURE;
    }

    char operator = argv[2][0];
    digit_to_list(&head1, &tail1, &head2, &tail2, argv);

    switch (operator)
    {
        case '+':
            addition(&head1, &tail1, &head2, &tail2, &headR, &tailR);
            printf("\nSum = ");
            break;
        case '-':
            subtraction(&head1, &tail1, &head2, &tail2, &headR, &tailR);
            printf("\nDifference = ");
            break;
        case 'x':
			multiplication(&head1,&tail1,&head2,&tail2,&headR,&tailR);
            printf("\nProduct = ");
            break;
        case '/':
            int ret = division(&head1,&tail1,&head2,&tail2,&headR,&tailR);
            if(ret != FAILURE){
                printf("\nDivision = ");
            }
            break;
        default:
            printf("Invalid Operator: Try again...\n");
            return FAILURE;
    }
    print_list(headR);
    printf("\n\n");
}


void digit_to_list(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, char *argv[])
{
    int i = 0;
    while (argv[1][i])
    {
        dl_insert_last(head1, tail1, (argv[1][i]) - '0');
        i++;
    }
    i = 0;
    while (argv[3][i])
    {
        dl_insert_last(head2, tail2, (argv[3][i]) - '0');
        i++;
    }
}

int dl_insert_last(Dlist **head, Dlist **tail, int dat)
{
    Dlist *new = malloc(sizeof(Dlist));
    if (new == NULL) return FAILURE;
    new->data = dat;
    new->next = NULL;
    if (*head == NULL)
    {
        new->prev = NULL;
        *head = new;
        *tail = new;
        return SUCCESS;
    }
    (*tail)->next = new;
    new->prev = *tail;
    *tail = new;
    return SUCCESS;
}

int dl_insert_first(Dlist **head, Dlist **tail, int dat)
{
    Dlist *new = malloc(sizeof(Dlist));
    if (new == NULL) return FAILURE;
    new->prev = NULL;
    new->data = dat;
    if (*head == NULL)
    {
        new->next = NULL;
        *head = new;
        *tail = new;
        return SUCCESS;
    }
    new->next = (*head);
    (*head)->prev = new;
    *head = new;
    return SUCCESS;
}

void print_list(Dlist *head)
{
    Dlist *temp = head;
    while (temp)
    {
        printf("%d", temp->data);
        temp = temp->next;
    }
    printf("\n");
}