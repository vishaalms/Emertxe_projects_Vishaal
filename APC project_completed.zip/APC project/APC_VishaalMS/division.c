#include"apc.h"


// Function to compare two numbers stored in doubly linked lists
int is_smaller(Dlist *head1, Dlist *head2) {
    int len1 = 0, len2 = 0;
    Dlist *temp1 = head1, *temp2 = head2;

    // Calculate the length of both numbers
    while (temp1) {
        len1++;
        temp1 = temp1->next;
    }
    while (temp2) {
        len2++;
        temp2 = temp2->next;
    }

    // If the first number has fewer digits, it's smaller
    if (len1 < len2) return 1;
    if (len1 > len2) return 0;

    // If they have the same length, compare digit by digit
    temp1 = head1;
    temp2 = head2;
    while (temp1 && temp2) {
        if (temp1->data < temp2->data) return 1;
        if (temp1->data > temp2->data) return 0;
        temp1 = temp1->next;
        temp2 = temp2->next;
    }
    return 0;  // Both are equal
}

// Function to subtract two numbers stored in doubly linked lists
void subtract(Dlist **head1, Dlist **tail1, Dlist *head2, Dlist *tail2) {
    Dlist *ptr1 = *tail1;
    Dlist *ptr2 = tail2;
    int borrow = 0;

    while (ptr1) {
        int dig1 = ptr1->data;
        int dig2 = (ptr2) ? ptr2->data : 0;

        int sub = dig1 - dig2 - borrow;
        if (sub < 0) {
            sub += 10;
            borrow = 1;
        } else {
            borrow = 0;
        }
        ptr1->data = sub;

        if (ptr2) ptr2 = ptr2->prev;
        ptr1 = ptr1->prev;
    }

    // Remove leading zeros in remainder
    while (*head1 && (*head1)->data == 0 && (*head1)->next) {
        *head1 = (*head1)->next;
        free((*head1)->prev);
        (*head1)->prev = NULL;
    }
}

// Function to divide two large numbers stored in doubly linked lists
int division(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR) {
    if (!(*head2) || ((*head2)->data == 0 && (*head2)->next == NULL)) {
        printf("Error: Division by zero is undefined.\n");
        return FAILURE;
    }

    if (!(*head1) || ((*head1)->data == 0 && (*head1)->next == NULL)) {
        *headR = *tailR = (Dlist *)malloc(sizeof(Dlist));
        (*headR)->data = 0;
        (*headR)->prev = (*headR)->next = NULL;
        return SUCCESS;
    }

    *headR = *tailR = NULL;
    Dlist *num1 = *head1;
    Dlist *rem_head = NULL, *rem_tail = NULL;

    while (num1) {
        // Append the next digit from num1 to remainder
        Dlist *new_node = (Dlist *)malloc(sizeof(Dlist));
        new_node->data = num1->data;
        new_node->prev = rem_tail;
        new_node->next = NULL;
        
        if (rem_tail) {
            rem_tail->next = new_node;
        } else {
            rem_head = new_node;
        }
        rem_tail = new_node;

        // Remove leading zeros in remainder
        while (rem_head && rem_head->data == 0 && rem_head->next) {
            rem_head = rem_head->next;
            free(rem_head->prev);
            rem_head->prev = NULL;
        }

        // Determine how many times divisor fits in remainder
        int count = 0;
        while (!is_smaller(rem_head, *head2)) {
            subtract(&rem_head, &rem_tail, *head2, *tail2);
            count++;
        }

        // Append quotient digit to result DLL
        Dlist *quotient_node = (Dlist *)malloc(sizeof(Dlist));
        quotient_node->data = count;
        quotient_node->prev = *tailR;
        quotient_node->next = NULL;

        if (*tailR) {
            (*tailR)->next = quotient_node;
        } else {
            *headR = quotient_node;
        }
        *tailR = quotient_node;

        num1 = num1->next;
    }

    // Remove leading zeros from result
    while (*headR && (*headR)->data == 0 && (*headR)->next) {
        *headR = (*headR)->next;
        free((*headR)->prev);
        (*headR)->prev = NULL;
    }
}
