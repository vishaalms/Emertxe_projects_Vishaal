#include"apc.h"

int compare_lists(Dlist *head1, Dlist *head2)
{
    int len1 = 0, len2 = 0;
    Dlist *temp1 = head1, *temp2 = head2;
    while (temp1) { len1++; temp1 = temp1->next; }
    while (temp2) { len2++; temp2 = temp2->next; }
    
    if (len1 > len2) return 1;
    if (len2 > len1) return -1;
    
    temp1 = head1;
    temp2 = head2;
    while (temp1 && temp2)
    {
        if (temp1->data > temp2->data) return 1;
        if (temp1->data < temp2->data) return -1;
        temp1 = temp1->next;
        temp2 = temp2->next;
    }
    return 0;
}

int subtraction(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR)
{
    int borrow = 0;
    Dlist *t1 = *tail1;
    Dlist *t2 = *tail2;
    int is_negative = 0;

    if (compare_lists(*head1, *head2) < 0)
    {
        is_negative = 1;
        Dlist *temp;
        temp = *head1; *head1 = *head2; *head2 = temp;
        temp = *tail1; *tail1 = *tail2; *tail2 = temp;
        t1 = *tail1;
        t2 = *tail2;
    }

    while (t1 || t2)
    {
        int diff = (t1 ? t1->data : 0) - (t2 ? t2->data : 0) - borrow;
        if (diff < 0)
        {
            borrow = 1;
            diff += 10;
        }
        else
        {
            borrow = 0;
        }
        dl_insert_first(headR, tailR, diff);
        if (t1) t1 = t1->prev;
        if (t2) t2 = t2->prev;
    }

    while (*headR && (*headR)->data == 0 && (*headR)->next)
    {
        Dlist *temp = *headR;
        *headR = (*headR)->next;
        free(temp);
    }
    if (!*headR) dl_insert_first(headR, tailR, 0);
    if (is_negative){
		(*headR)->data =   ( ((*headR)->data)  *  (-1)  ) ; 
	}
}