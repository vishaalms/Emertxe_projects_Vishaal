#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mainheader.h"
#include <stdio_ext.h>

void listContacts(AddressBook *addressBook) 
{
    if((addressBook->contactCount) == 0) printf("\n\nAddress Book is Empty!!\n\n\n");
    else
    {
    int sno = 1;
    printf("-------------------------------------------------------------------------------------------\n");
    printf("Name                   Phone               Email\n\n");
    for(int i = 0 ; i <  (addressBook -> contactCount); i++ )
    {
        printf("%d.%s", sno , addressBook -> contacts[i].name);
        int spaces;
        int namecount = 0;
        for(int x=0; (addressBook -> contacts[i].name[x]) ;  x++)   namecount++;
        if(sno >= 1   &&    sno <= 9)    spaces = (23 - (namecount + 2));
        else if(sno >= 10 && sno <= 99)  spaces = (23 - (namecount + 3));
        else if(sno == 100)    spaces = (23 - (namecount + 4));
        for(int x=0; x < spaces ; x++) printf(" ");
        printf("%s", addressBook -> contacts[i].phone);
        printf("          %s\n", addressBook -> contacts[i].email);
        sno ++;
    }
    printf("-------------------------------------------------------------------------------------------\n");  
    }
}

void initialize(AddressBook *addressBook) 
{

    populateAddressBook(addressBook);
}




void createContact(AddressBook *addressBook) 
{

    
    __fpurge(stdin);
    printf("You have selected to create a new contact\n");
    printf("Enter the name: ");
    scanf("%24[^\n]s", addressBook -> contacts[addressBook -> contactCount].name);
    __fpurge(stdin);
    printf("Enter the phone number: ");
    scanf("%10[^\n]s", addressBook -> contacts[addressBook -> contactCount].phone);
    __fpurge(stdin);
    printf("Enter the email: ");
    scanf("%50[^\n]s", addressBook -> contacts[addressBook -> contactCount].email);

    (addressBook -> contactCount)++;

    printf("\n\n\nContact Added!!\n\n\n");

}

void searchContact(AddressBook *addressBook) 
{
    if((addressBook->contactCount) == 0) printf("\n\nAddress Book is Empty!!\n\n\n");
    else
    {
    char namee[25];
    __fpurge(stdin);
    printf("Enter the name of the contact to be searched: ");
    scanf("%24[^\n]s", namee);
    
    int flag = 0;
    int sno = 1;
    printf("-------------------------------------------------------------------------------------------\n");
    for(int i = 0 ; i < (addressBook -> contactCount) ; i++)
    {
        
        if(   strcmp(namee , addressBook->contacts[i].name)  == 0  )
        {
            printf("%d.Name: %s         ",sno, addressBook->contacts[i].name);
            printf("Phone_Number: %s         ", addressBook->contacts[i].phone);
            printf("Email_ID: %s\n", addressBook->contacts[i].email);
            flag = 69;
            sno ++;
        }
    }
    if(flag == 0) printf("Contact Not Found.\n");
    printf("-------------------------------------------------------------------------------------------\n\n");
    }
}

void editContact(AddressBook *addressBook) 
{
    if((addressBook->contactCount) == 0)  printf("\n\nAddress Book is Empty!!\n\n\n");
    else
    {
    listContacts(addressBook);
    int con;
    __fpurge(stdin);
    printf("Enter the S.No. of the contact to be edited: ");
    scanf("%d", &con);
    int index = con - 1;
    if(index < 0  || index >= (addressBook->contactCount)) 
    {
        printf("\nEnter a valid S.No. to be edited\n\n");
        editContact(addressBook);
    }
    else{
    __fpurge(stdin);
    printf("Enter the new name: ");
    scanf("%24[^\n]s", addressBook->contacts[index].name);
    __fpurge(stdin);
    printf("Enter the new phone number: ");
    scanf("%10[^\n]s", addressBook->contacts[index].phone);
    __fpurge(stdin);
    printf("Enter the new Email id: ");
    scanf("%50[^\n]s", addressBook->contacts[index].email);

    printf("\n\nContact Updated!.\n\n"); 
        }
    }

}

void deleteContact(AddressBook *addressBook) 
{
    if((addressBook->contactCount) == 0  )  printf("\n\nAddress Book is Empty!!\n\n\n");
    else
    {
    listContacts(addressBook);
    int con;
    __fpurge(stdin);
    printf("Enter the S.No. of the contact to be deleted: ");
    scanf("%d", &con);

    

    int index = con - 1  ;

    if(index < 0  || index >= (addressBook->contactCount))
    {
        printf("\nEnter a valid S.No. to be deleted\n\n");
        deleteContact(addressBook);
    }
    else
    {
    for(int i = index ; i < (addressBook->contactCount) ; i++)
    {
        strcpy(addressBook->contacts[i].name ,  addressBook->contacts[i+1].name );
        strcpy(addressBook->contacts[i].phone ,  addressBook->contacts[i+1].phone );
        strcpy(addressBook->contacts[i].email ,  addressBook->contacts[i+1].email );
    }
    (addressBook->contactCount) -- ;

    printf("\n\nContact Deleted!.\n\n\n");
        }
    }

}


//