#include <stdio.h>
#include "mainheader.h"
#include <string.h>
#include <stdlib.h>
#include <stdio_ext.h>

void saveContactsToFile(AddressBook *addressBook) 
{
    FILE * fptr;
    fptr = fopen("book.csv", "w+");
    fprintf(fptr, "#%d#\n",    addressBook->contactCount  );
    for(int i = 0 ; i < addressBook->contactCount   ; i++){
        fprintf(fptr, "%s,%s,%s\n", addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }
    fclose(fptr);
    printf("\n\nContacts Saved to the Address book\n\n");
}

void loadContactsFromFile(AddressBook *addressBook) 
{
    FILE * fptr;
    fptr = fopen("book.csv" , "r");
    int count;
    fscanf(fptr , "#%d#\n" ,   &count  );

    char na[25];
    char ph[11];
    char em[51];
    for(int i = 0 ; i < 25 ; i++) na[i] = 0;
    for(int i = 0 ; i < 11 ; i++) ph[i] = 0;
    for(int i = 0 ; i < 51 ; i++) em[i] = 0;


    for(int i = 0; i < count ; i++){
        fscanf(fptr , "%24[^',']s" , na );
        fseek(fptr,  1  ,  SEEK_CUR);
        fscanf(fptr,  "%10[^',']s" , ph);
        fseek(fptr,  1  ,  SEEK_CUR);
        fscanf(fptr , "%50[^\n]s" ,  em);
        fseek(fptr,  1  ,  SEEK_CUR);

        strcpy(addressBook->contacts[addressBook->contactCount].name , na);
        strcpy(addressBook->contacts[addressBook->contactCount].phone , ph);
        strcpy(addressBook->contacts[addressBook->contactCount].email , em);
        (addressBook->contactCount) ++ ;

        for(int i = 0 ; i < 25 ; i++) na[i] = 0;
        for(int i = 0 ; i < 11 ; i++) ph[i] = 0;
        for(int i = 0 ; i < 51 ; i++) em[i] = 0;
    }

    printf("\n\nContacts appended from the Address Book\n\n\n");
}
//