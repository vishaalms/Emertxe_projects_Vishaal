#ifndef MAINH_H
#define MAINH_H



#define MAX_CONTACTS 100

typedef struct {
    char name[25];
    char phone[11];
    char email[51];
} Contact;

typedef struct {
    Contact contacts[MAX_CONTACTS];
    int contactCount;
    
} AddressBook;

void createContact(AddressBook *addressBook);
void searchContact(AddressBook *addressBook);
void editContact(AddressBook *addressBook);
void deleteContact(AddressBook *addressBook);
void listContacts(AddressBook *addressBook);
void initialize(AddressBook *addressBook);
void saveContactsToFile(AddressBook *addressBook);
void loadContactsFromFile(AddressBook *addressBook);
void populateAddressBook(AddressBook* addressBook);

#endif
