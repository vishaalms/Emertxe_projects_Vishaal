#include <stdio.h>
#include "mainheader.h"
#include <stdlib.h>
#include <stdio_ext.h>

int main() 
{
    int choice;
    AddressBook  book ;
    initialize(&book);
    while(1)
    {
        printf("Choose an option from the below list\n");
        printf("1.Create a new contact\n");
        printf("2.Search contact\n");
        printf("3.Edit contact\n");
        printf("4.Delete contact\n");
        printf("5.List contacts\n");
        printf("6.Save contacts to Address Book\n");
        printf("7.Load contacts from Address Book\n");
        printf("8.Exit\n");
        
        scanf("%d", &choice);

        switch(choice)
        {
            case 1:
                createContact(&book);
                break;

            case 2:
                searchContact(&book);
                break;

            case 3:
                editContact(&book);
                break;

            case 4:
                deleteContact(&book);
                break;

            case 5:
                listContacts(&book);
                break;

            case 6:
                saveContactsToFile(&book);
                break;

            case 8:
                printf("\nDo you want to save the changes to the Address Book? (y/n): ");
                char h;
                __fpurge(stdin);
                scanf("%c", &h);
                if(h == 'y'){
                    saveContactsToFile(&book);
                    return 0;
                }
                else if(h == 'n'){
                    return 0;
                }
                else{
                    printf("\n\nInvalid Option!!\n\n\n");
                }
                break;

            case 7:
                loadContactsFromFile(&book);
                break;

            default:
                printf("\n\nInvalid Option! Try Again !!\n\n");
                break;

        }

    }
    return 0 ;
}
