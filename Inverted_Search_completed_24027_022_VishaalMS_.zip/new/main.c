#include "inverted_Search.h"

int main(int argc , char *argv[])
{
    system("clear");

    

    //1.validate the input arguments
    if(argc <= 1)
    {
        printf("Enter the valid no. of arguments \n");
        printf("./Slist.exe file1.txt file2.txt ..... \n");
        return 0;
    }

    //create file linked list 
    // declare the head pointer 

    Flist *f_head = NULL;

        //validation of input files
    file_validation_n_file_list(&f_head ,argv);
    if(f_head == NULL)
    {
        printf("No files are added to file linked list\n");
        printf("Hence the process got terminated\n");
        return 1;
    }


    Wlist * head[27] = {NULL};

    
/*..........2.TODO...............
    Select your choice among following options:
1. Create DATABASE
2. Display Database
3. Update DATABASE
4. Search
5. Save Database
6. Exit
Enter your choice.
        switch(choice)

        case1 : create database(f_head , head);
        break;
        case2 : display_database(head);
        break;
        case3 : update_database(head,&f_head );
        break;
        case4 : search
        char word[WORD_SIZE]; 
        printf("Enter the word to search\n");
        scanf("%s" , word);
        int index = tolower(word[0]) % 97;
        search(head[index] , word);

        break;

        case5 : save_database(head)
*/     
    int flag_for_1 = 0 ;
    while(1){
    printf("Select your choice among following options:\n");
    printf("1. Create DATABASE\n2. Display Database\n3. Update DATABASE\n4. Search\n5. Clear Database\n6. Save Database\n7. Exit\nEnter your choice: ");
    int choice ;
    scanf("%d" ,   &choice );
    switch(choice){
        case 1 :
            create_database(f_head,head);
            printf("\nSuccessfully Created Database\n\n");
            break;
        case 2 :
            printf("\n1. Display in traditional style\n2. Display in new style(Own)\nEnter your choice: ");
            int st ;
            scanf("%d"  ,  &st );
            if(st == 2)
                display_database(head);
            else if(st == 1){
                disp_trad(head);
            }
            else printf("\nInvalid Option\n");
            break;
        case 3 :
            int retu = update_database(head, &f_head );
            if(retu == REPEATATION){
                printf("\nThis file already exists !\n\n");
            }
            else if(retu == FILE_EMPTY){
                printf("\nFile Empty !!\n\n");
            }
            else if(retu == FILE_NOTAVAILABLE){
                printf("\nFile not available !!\n\n");
            }
            else{
                printf("\nUpdated Database Successfully\n\n");
            }
            break;
        case 7 :
            return 0 ;
        case 5:
            del(head);
            printf("\nDatabase cleared Successfully\n\n");
            break ;
        case 4:
            printf("Enter the word to search for: ");
            char sword[16];
            __fpurge(stdin);
            scanf("%s" ,   sword   );
            for(int i= 0 ; sword[i] ; i++   ){
                sword[i] =  tolower(sword[i]) ;
            }
            int index = sword[0] % 97 ;
            if( !(index >= 0   &&   index <= 25)  )
                index = 26 ;
            int ret = search(head[index] , sword  );
            break ;
        case 6:
            int returnn = save_database(head);
            if(returnn != FAILURE)
                printf("\nDatabase saved Successfully\n");
            break;
        default:
            printf("\nInvalid Choice!!\n");
            break;
    }
    }
}
