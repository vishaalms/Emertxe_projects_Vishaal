#include "inverted_search.h"





int print_word_count(Wlist *head)
{
    //traverse through the list 
    while(head)
    {
        if(tolower(head->word[0]) >=  'a'  &&  tolower(head->word[0]) <= 'z'  )
            printf("[%2d]" , tolower(head->word[0]) %97 );
        else
            printf("[26]");
        
        printf("            [%10s]" ,   head->word  ) ;
        printf("    %d file/s          " ,  head->file_count    );
        Ltable *Thead = head->Tlink;

        //traverse through the Ltable list 
        while(Thead)
        {
            printf("(File: %s  %d) " , Thead->file_name , Thead->word_count);
            Thead = Thead->table_link;
        }
        printf("\n");
        head = head->link;
    }
}


void display_database( Wlist *head[]){
    for(int i = 0 ;  i<= 26 ; i++  ){
        printf("[%d] -> " , i);
        if(head[i] == NULL ) {
            printf("NULL");
        }
        else{
            Wlist * temp = head[i];
            while(temp->link){
                printf("[%d, %s, " ,   temp->file_count ,  temp->word   );
                
                Ltable * intemp = temp->Tlink ;
                while(intemp->table_link){
                    
                    printf("(%d, %s) -> "  ,  intemp->word_count ,  intemp->file_name   );
                    intemp = intemp->table_link ;
                }
                printf("(%d, %s) -> NULL ] -> ",  intemp->word_count ,  intemp->file_name);
                temp = temp->link;    
            }
            printf("[%d, %s, " ,   temp->file_count ,  temp->word   );
                
            Ltable * intemp = temp->Tlink ;
            while(intemp->table_link){
                
                printf("(%d, %s) -> "  ,  intemp->word_count ,  intemp->file_name   );
                intemp = intemp->table_link ;
            }
            printf("(%d, %s) -> NULL ] -> NULL",  intemp->word_count ,  intemp->file_name);
        }
        printf("\n");
    }

}

void disp_trad(Wlist * head[]){
    printf("[index]         [word]          [file_count]      [File_name and word_count]\n");
    printf("----------------------------------------------------------------------------------------\n");

    for(int i = 0; i< 27; i++)
    {
        if(head[i] != NULL)
        {
            print_word_count(head[i]);
        }
    }

}