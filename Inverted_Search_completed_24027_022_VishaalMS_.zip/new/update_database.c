#include "inverted_search.h"

int update_database( Wlist *head[], Flist **f_head)
{
    char file_name[FNAME_SIZE];
    //prompt the user for new file name 

    printf("Enter the file name to update the database\n");
    __fpurge(stdin);
    scanf("%s" , file_name);

    int rett = isFileEmpty(file_name);
    if(rett == FILE_NOTAVAILABLE)  return FILE_NOTAVAILABLE ;
    else if(rett == FILE_EMPTY)  return FILE_EMPTY ;

    

    Flist * temp = *f_head;
    while(temp)
    {
        if(!strcmp(temp->file_name , file_name))
        {
            return REPEATATION ;
        }
        temp = temp->link;
    }

    //......4.TODO......
    //(copy validation part)
    temp = *f_head;
    while(temp->link){
        temp = temp->link;
    }
    Flist * new = malloc(sizeof(Flist));
    strcpy(new ->file_name , file_name);
    new ->link = NULL ;

    temp -> link = new ;

    
    
    create_database((*f_head) ,  head   );

    return SUCCESS ;


}