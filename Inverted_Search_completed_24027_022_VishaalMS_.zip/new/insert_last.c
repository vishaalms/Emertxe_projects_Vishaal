#include"inverted_Search.h"

int insert_at_last(Wlist **head, data_t *data , char * file_name){

    char strr[WORD_SIZE] ;
    int i;
    for( i = 0; data[i] ; i++){
        strr[i] = tolower(data[i]);
    }
    strr[i] = 0;

    Wlist * new = malloc(sizeof(Wlist));
    new -> file_count = 1;
    strcpy(new -> word , strr );
    new ->link = NULL ;
    new ->Tlink = malloc(sizeof(Ltable));
    new -> Tlink -> word_count = 1; 
    strcpy(new -> Tlink -> file_name ,  file_name) ;
    new -> Tlink -> table_link = NULL;
    if(*head == NULL){
        
        *head = new ;
        return SUCCESS;
    }
    Wlist * temp = *head ;
    while(temp -> link){
        temp = temp -> link ;
    }

    temp ->link = new ;
    return SUCCESS ;

}

int update_word_count(Wlist * head, char * file_name)
{
    //..........3 . TODO..........
    // check filenames are same or not
    // if file names are same : increment word count 
    // if file names are different : increment file count and create Ltable new node
    int flag  =  0;
    Ltable *  temp = head ->Tlink ;
    while(temp->table_link){
        if(strcmp(file_name ,  temp->file_name  ) ==  0 ){
            flag = 1;
            break;
        }
        temp = temp->table_link;
    }
    if(strcmp(file_name ,  temp->file_name  ) ==  0 ){
        flag = 1;
    }
    if(flag == 1){
        (temp->word_count)++;
    }
    else{
        (head->file_count)++;
        Ltable * new = malloc(sizeof(Ltable));
        strcpy(new ->file_name , file_name);
        new->table_link = NULL;
        new->word_count = 1 ;
        temp->table_link = new ;
    }
    


}
