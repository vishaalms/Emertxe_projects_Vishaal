#include"inverted_Search.h"

//char *fname;

int create_database(Flist *f_head, Wlist *head[])
{
    del(head);
    printf("\nDataBase Cleared !\n");
    // traverse through file linked list 
    while(f_head)
    {
        read_datafile(f_head , head, f_head->file_name);
        f_head = f_head->link;
    }

}
// read the content of a file 
Wlist * read_datafile(Flist *file, Wlist *head[], char *filename)
{

    //fname = filename;
    //open the file in read mode

    FILE *fptr = fopen(filename , "r");

    //declare an array to store word 
    char word[WORD_SIZE];
    
    while(fscanf(fptr , "%s" , word) != EOF)
    {
        int flag = 1;
        // find index 
        int index = tolower(word[0]) % 97;
        
        //other than alphabets 
        if(!(index >= 0 && index <= 25))
            index = 26;

        // check for repeatancy of words 
        if(head[index] !=  NULL)
        {
            Wlist *temp = head[index];
            //compare each node words with new word 
            while(temp)
            {
                char  str1[WORD_SIZE] ;
                char  str2[WORD_SIZE] ;
                int i;
                for( i = 0; temp->word[i]; i++){
                    str1[i] = tolower(temp->word[i]);
                }
                str1[i] = 0;
                
                for(i = 0; word[i]; i++){
                    str2[i] = tolower(word[i]);
                }
                str2[i] = 0;

                if(!strcmp (str1 , str2))
                {
                    update_word_count(temp, filename);
                    flag = 0;
                    break;
                }
                temp = temp->link ;
            }

        }
        
        // call when words are not repeated 
        if(flag == 1)
        {
            insert_at_last(&head[index] , word ,    filename );
        }
    }
}



void  del(Wlist * head[]){
    for(int i = 0 ;  i<= 26 ; i++  ){
        
        
        if(head[i] != NULL ){
            Wlist * temp = head[i];
            while(temp->link){
                
                
                Ltable * intemp = temp->Tlink ;
                while(intemp->table_link){
                    Ltable * del = intemp ;
                    intemp = intemp->table_link ;
                    free(del);
                }
                free(intemp);
                temp ->Tlink = NULL ;
                Wlist * delo = temp;
                temp = temp->link;
                free(delo);    
            }    
            Ltable * intemp = temp->Tlink ;
            while(intemp->table_link){
                Ltable * del = intemp;
                intemp = intemp->table_link ;
                free(del);
            }
            free(intemp);
            temp->Tlink = NULL ;
            free(temp);
            head[i] = NULL ;         
        }
        
    }


}

