/*
 * File:   main.c
 * Author: Vishaal  MS
 *
 * Created on 14 April, 2025, 2:52 PM
 */


#include "main.h"

#pragma config WDTE = OFF

//9 is the latest event , 0 is the oldest event   (out of 10)  

unsigned char org_pass[6];
unsigned long int tmrcount = 0;
unsigned int seconds = 60 ;

void __interrupt() isr(void)
{
    
    
    if (TMR0IF == 1)
    {
        /* TMR0 Register valur + 6 (offset count to get 250 ticks) + 2 Inst Cycle */
        TMR0 = TMR0 + 8;
        
        if (++tmrcount == 1250)
        {
            tmrcount = 0;
            seconds--;
            
        }
        
        TMR0IF = 0;
    }
}

void init_config(){
    TRISB =0 ; PORTB = 0 ; TRISD = 0 ; PORTD = 0 ;
    init_digital_keypad();
    init_clcd();
    init_i2c(100000);
    init_ds1307();
    init_adc();
    init_timer0();
    init_uart(9600);
}


void main() {
    init_config();
    
    
    unsigned char flag = 0 ;
    
    unsigned char * events[] = { "ON" , "GN" , "G1" , "G2" , "G3" , "G4" , "GR" , "C "  } ;
    int curr_event = 0 ;
    unsigned char key ;
    unsigned char speed = 0 ;
    
    for(unsigned char i =0 ; i<5 ; i++ ){
        org_pass[i] = ext_eeprom_24C02_read(i) ;
    }
    org_pass[5] = 0 ;
    unsigned char entered_pass[] = "     " ;
    unsigned char blink_index = 0 ;
    unsigned char blink_delay = 0 ;
    unsigned int nbdelay = 500;
    unsigned char locked_flag = ext_eeprom_24C02_read(106);
    if(locked_flag == 1){
        //locked
        flag = 3 ;
        clcd_print("LockedFor_60Secs"   , LINE1(0));
        clcd_print("........        "   , LINE2(0));
        GIE = 1 ;
        TMR0 = 6;
    }
    unsigned char attempt_count = ext_eeprom_24C02_read(107);
    
    unsigned char * mm[] = { " View Log      " , " Clear Log     "," Download Log  " ,  " Set time      "," Change Pwd    ","               "};
    short int mmdispline1 = 0 ; short int mmdispline2 = 1 ;
    unsigned char mmkey;
    short int mmpointer = 0 ;  unsigned  int wait = 0 ;
    unsigned char down = 0 ;  unsigned char up = 0 ;
    unsigned int menureturndelay = 50;
    unsigned char sno = 1 ;
    short int viewlogindex  = 9 ;
    unsigned char vlkey ;
    unsigned int vlwait = 0 ;
    unsigned char vldown = 0 ;  unsigned char vlup = 0 ;
    
    int stsec = 0 ; int stmin = 0 ; int sthr = 0 ; unsigned char stblinkf = 0 ; unsigned char stkey;
    unsigned int stwait = 0 ;  unsigned char stup = 0 ;
    
    log_car_event("ON" ,  0 );
    
    while(1){
        
        
        
        key = read_digital_keypad(STATE);
        
        
        if(flag == 0){
                       
            if(key == SW1){
                curr_event = 7 ;
                log_car_event( events[curr_event] ,  speed    );
            }
            else if(key == SW2){
                if(curr_event == 7 ){
                    curr_event = 1 ;
                }
                else{
                    curr_event++ ;
                    if(curr_event == 7 ) curr_event -- ;
                }
                log_car_event( events[curr_event] ,  speed    );
            }
            else if(key == SW3){
                if(curr_event == 7 ){}
                else{
                    curr_event--;
                    if(curr_event <= 0) curr_event ++ ;
                }
                log_car_event( events[curr_event] ,  speed    );
            }
            
            
            if(curr_event == 2  || curr_event == 3 || curr_event == 4 || curr_event == 5 || curr_event == 6 ){
                speed = (unsigned char) ((read_adc())/10) ;
                if(speed > 99) speed = 99 ;
            }
            else{
                speed = 0 ;
            }
            
            
            
            clcd_print("  TIME    E   SP" , LINE1(0) );
            display_time();
            clcd_putch(' '  ,  LINE2(8) );
            clcd_putch(' '  ,  LINE2(9) );
            clcd_print(events[curr_event]  , LINE2(10) );
            clcd_putch(' '  ,  LINE2(12) );
            clcd_putch(' '  ,  LINE2(13) );
            clcd_putch(      (speed/10) + '0'           ,   LINE2(14)      );
            clcd_putch(      (speed%10) + '0'           ,   LINE2(15)      );
            
            if(key == SW4 ||  key == SW5){
                key = ALL_RELEASED ;
                flag = 1 ;
                clcd_print( " Enter Password "  ,  LINE1(0));
                clcd_print( "                "   ,  LINE2(0)   );
                blink_index = 0 ;
                blink_delay = 0 ;
                nbdelay = 500;
            }
            
        }
        if(flag == 1){
            
            
            if(blink_delay++ < 4){
                clcd_putch(0xFF ,  LINE2(blink_index) );
            }else if(blink_delay < 8){
                clcd_putch( ' ' ,  LINE2(blink_index) );
            }else  blink_delay = 0 ;
            
            if(key == SW4){
                key = ALL_RELEASED ;
                entered_pass[blink_index] = '0' ; 
                clcd_putch( '*' ,  LINE2(blink_index) );
                blink_index++;
                nbdelay = 500;
                
            }else if(key == SW5){
                key = ALL_RELEASED ;
                entered_pass[blink_index] = '1' ;
                clcd_putch( '*' ,  LINE2(blink_index) );
                blink_index++;
                nbdelay = 500;
            }
            
            if(strcmp(entered_pass , org_pass  ) == 0){
                //Correct password
                flag = 2 ;//menu
                clcd_print("                " , LINE1(0) );
                clcd_print("                " , LINE2(0) );
                entered_pass[0] = ' ' ;
                entered_pass[1] = ' ' ;
                entered_pass[2] = ' ' ;
                entered_pass[3] = ' ' ;
                entered_pass[4] = ' ' ;
                blink_index = 0 ;
                nbdelay = 500 ;
                menureturndelay = 50;
                attempt_count = 3 ;
                ext_eeprom_24C02_byte_write(107 , 3 );
                mmdispline1 = 0 ;
                mmdispline2 = 1 ;  mmpointer = 0;
            }
            if(blink_index == 5){
                //Wrong password
                entered_pass[0] = ' ' ;
                entered_pass[1] = ' ' ;
                entered_pass[2] = ' ' ;
                entered_pass[3] = ' ' ;
                entered_pass[4] = ' ' ;
                blink_index = 0 ;
                nbdelay = 500 ;
                attempt_count--;
                if(attempt_count != 0){
                    ext_eeprom_24C02_byte_write(107 , attempt_count );
                    clcd_print("Wrong password! "  ,  LINE1(0));
                    clcd_print("Attempts: "  ,   LINE2(0));
                    clcd_putch( attempt_count + '0'    ,   LINE2(10)  );
                    clcd_print("     "  ,   LINE2(11));
                    __delay_ms(3700);
                    clcd_print( " Enter Password "  ,  LINE1(0));
                    clcd_print( "                "   ,  LINE2(0)   );
                }else{
                    //locked for 60secs screen
                    flag = 3 ;
                    attempt_count = 3 ;
                    ext_eeprom_24C02_byte_write(107 , 3 );
                    ext_eeprom_24C02_byte_write(106 , 1 );
                    clcd_print("LockedFor_60Secs"   , LINE1(0));
                    clcd_print("........        "   , LINE2(0));
                    tmrcount = 0 ;
                    seconds = 60 ;
                    GIE = 1 ;
                    TMR0 = 6 ;
                }
            }
            
            
            if(!nbdelay--){
                nbdelay = 500 ;
                flag = 0 ;
                entered_pass[0] = ' ' ;
                entered_pass[1] = ' ' ;
                entered_pass[2] = ' ' ;
                entered_pass[3] = ' ' ;
                entered_pass[4] = ' ' ;
                blink_index = 0 ;
            }
            
        }
        if(flag == 3){
            clcd_putch( (seconds/10) + '0'  ,  LINE1(10)  );
            clcd_putch( (seconds%10) + '0'  ,  LINE1(11)  );
            
            if(seconds == 0){
                GIE = 0 ;
                ext_eeprom_24C02_byte_write(106 , 0 );
                attempt_count = 3 ;
                ext_eeprom_24C02_byte_write(107 , 3 );
                flag =  0;
                
            }
            
        }
        if(flag == 2){
            //menu display
            mmkey = read_digital_keypad(LEVEL);
            
            clcd_print( mm[mmdispline1] , LINE1(1) );
            clcd_print( mm[mmdispline2] , LINE2(1) );
            
            if(mmpointer == 0){
                clcd_putch('*' ,  LINE1(0) );
                clcd_putch(' ' ,  LINE2(0) );
            }else{
                clcd_putch(' ' ,  LINE1(0) );
                clcd_putch('*' ,  LINE2(0) );
            }
            
            
            while(mmkey == SW5){
                menureturndelay = 50;
                mmkey = read_digital_keypad(LEVEL);
                if(mmkey == ALL_RELEASED) wait = 0 ;
                down = 1 ;
                if(wait++  > 65000 ){
                    down = 0;
                    wait = 0 ;
                    flag = 0 ;
                    break ;
                }
            }
            if(down == 1){
                wait = 0 ;
                down = 0 ;
                mmpointer++; 
                if(mmpointer == 2){
                    mmpointer = 0;
                    mmdispline1 = mmdispline1 + 2 ;
                    mmdispline2 = mmdispline2 + 2;
                }
                if(mmpointer == 1   &&  mmdispline1 == 4   ){
                    mmpointer = 0 ; 
                }
            }
            while(mmkey == SW4){
                menureturndelay = 50;
                mmkey = read_digital_keypad(LEVEL);
                if(mmkey == ALL_RELEASED) wait = 0 ;
                up = 1 ;
                if(wait++  > 65000){
                    up = 0;
                    wait = 0 ;
                    if(mmdispline1 == 0 && mmdispline2 == 1  && mmpointer == 0  ){
                        flag = 4 ; sno = 1; viewlogindex  = 9 ;
                        clcd_print("                " , LINE1(0) );
                        clcd_print("                " , LINE2(0) );
                    }
                    else if(mmdispline1 == 0 && mmdispline2 == 1  && mmpointer == 1  ) flag = 5 ;
                    else if(mmdispline1 == 2 && mmdispline2 == 3  && mmpointer == 0  ) flag = 6 ;
                    else if(mmdispline1 == 2 && mmdispline2 == 3  && mmpointer == 1  ){
                        flag = 7 ;
                        clcd_print("    HH:MM:SS    " , LINE1(0));
                        clcd_print("    00:00:00    " , LINE2(0));
                        stsec = 0 ;  stmin = 0 ;  sthr = 0 ;
                        blink_delay = 0; stblinkf = 0 ;
                        __delay_ms(1800);
                    }
                    else if(mmdispline1 == 4 && mmdispline2 == 5  && mmpointer == 0  ){
                        flag = 8 ;
                        clcd_print("Enter Curr Pwd :"  ,  LINE1(0)  );
                        clcd_print("                "  ,  LINE2(0)) ;
                        blink_index = 0 ;
                        blink_delay = 0 ;
                        nbdelay = 500 ;
                        entered_pass[0] = ' ' ; entered_pass[1] = ' ' ;entered_pass[2] = ' ' ; entered_pass[3] = ' ' ;
                        entered_pass[4] = ' ' ;  key = ALL_RELEASED ;
                    }
                    break ;
                }
            }
            if(up == 1){
                wait = 0 ;
                up = 0 ;
                mmpointer -- ;
                if(mmpointer == -1){
                    mmpointer = 1;
                    mmdispline1 = mmdispline1 - 2 ;
                    mmdispline2 = mmdispline2 - 2;
                }
                if(mmpointer == 1   &&   mmdispline1 == -2 ){
                    mmpointer = 0 ;
                    mmdispline1 = 0 ; mmdispline2 = 1;
                }
                
            }
            if(mmkey == ALL_RELEASED) wait = 0 ;
            
            if(!menureturndelay--){
                menureturndelay = 50;
                flag = 0;
                mmpointer = 0 ;
                mmdispline1 = 0 ; mmdispline2 = 1;
                wait = 0;
            }
            
            
        }
        if(flag == 4){
            vlkey = read_digital_keypad(LEVEL);
            
            unsigned char ev_count = ext_eeprom_24C02_read(108);
            if(ev_count == 0){
                clcd_print(" Log is Empty!  " , LINE1(0));
                clcd_print("                " , LINE2(0));
            }
            else{
            
                clcd_print("L TIME     E  SP" , LINE1(0));
                clcd_putch( ':'  ,   LINE2(4));
                clcd_putch( ':'  ,   LINE2(7));
                
                display_log(viewlogindex);
                
                
            }
            
            while(vlkey == SW5){
                
                vlkey = read_digital_keypad(LEVEL);
                if(vlkey == ALL_RELEASED) vlwait = 0 ;
                vldown = 1 ;
                if(vlwait++  > 65000 ){
                    vldown = 0;
                    vlwait = 0 ;
                    flag = 2 ;
                    break ;
                }
            }
            if(vldown == 1){
                vldown = 0 ;
                vlwait = 0 ;
                sno++;
                viewlogindex--;
                if(sno > ev_count){
                    sno--;
                    viewlogindex++;
                }
            }
            while(vlkey == SW4){
                vlkey = read_digital_keypad(LEVEL);
                if(vlkey == ALL_RELEASED) vlwait = 0 ;
                vlup = 1;
                if(vlwait++  > 65000 ){
                    
                    vlwait = 0 ;
                    
                    break ;
                }
            }
            if(vlup == 1){
                vlup = 0 ;
                vlwait = 0;
                sno--;
                viewlogindex++;
                if(sno == 0){
                    sno = 1;
                    viewlogindex =  9 ;
                }
            }
            if(vlkey == ALL_RELEASED) vlwait = 0 ;
            
            
        }
        if(flag == 5){
            clcd_print("Logs Cleared!   " ,  LINE1(0));
            clcd_print("                " ,  LINE2(0));
            
            ext_eeprom_24C02_byte_write(105 ,   0);
            ext_eeprom_24C02_byte_write(108 ,   0);
            
            __delay_ms(3000);
            
            flag = 2 ;
        }
        if(flag == 8){
            if(blink_delay++ < 4){
                clcd_putch(0xFF ,  LINE2(blink_index) );
            }else if(blink_delay < 8){
                clcd_putch( ' ' ,  LINE2(blink_index) );
            }else  blink_delay = 0 ;
            
            if(key == SW4){
                key = ALL_RELEASED ;
                entered_pass[blink_index] = '0' ; 
                clcd_putch( '*' ,  LINE2(blink_index) );
                blink_index++;
                nbdelay = 500;
                
            }else if(key == SW5){
                key = ALL_RELEASED ;
                entered_pass[blink_index] = '1' ;
                clcd_putch( '*' ,  LINE2(blink_index) );
                blink_index++;
                nbdelay = 500;
            }
            
            if(strcmp(entered_pass , org_pass  ) == 0){
                //Correct password
                flag = 9 ; //Entering new password
                entered_pass[0] = ' ' ; entered_pass[1] = ' ' ;entered_pass[2] = ' ' ; entered_pass[3] = ' ' ;
                entered_pass[4] = ' ' ;
                blink_index = 0 ; blink_delay = 0 ;
                nbdelay = 500;
                clcd_print("Enter new pwd:  " ,  LINE1(0));
                clcd_print("                " ,  LINE2(0));
                
            }
            if(blink_index == 5){
                clcd_print("Wrong Password! " ,  LINE1(0));
                clcd_print("                " ,  LINE2(0));
                //Wrong password
                entered_pass[0] = ' ' ;
                entered_pass[1] = ' ' ;
                entered_pass[2] = ' ' ;
                entered_pass[3] = ' ' ;
                entered_pass[4] = ' ' ;
                blink_index = 0 ; blink_delay = 0 ;
                nbdelay = 500 ;
                __delay_ms(5000);
                flag = 2 ;
            }
            
            
            if(!nbdelay--){
                nbdelay = 500 ;
                flag = 2 ;
                entered_pass[0] = ' ' ;
                entered_pass[1] = ' ' ;
                entered_pass[2] = ' ' ;
                entered_pass[3] = ' ' ;
                entered_pass[4] = ' ' ;
                blink_index = 0 ;
            }
            
            
        }
        if(flag == 9){
            if(blink_delay++ < 4){
                clcd_putch(0xFF ,  LINE2(blink_index) );
            }else if(blink_delay < 8){
                clcd_putch( ' ' ,  LINE2(blink_index) );
            }else  blink_delay = 0 ;
            
            if(key == SW4){
                key = ALL_RELEASED ;
                entered_pass[blink_index] = '0' ; 
                clcd_putch( '*' ,  LINE2(blink_index) );
                blink_index++;
                nbdelay = 500;
                
            }else if(key == SW5){
                key = ALL_RELEASED ;
                entered_pass[blink_index] = '1' ;
                clcd_putch( '*' ,  LINE2(blink_index) );
                blink_index++;
                nbdelay = 500;
            }
            
            if(blink_index == 5){
                //success done changing
                blink_index = 0 ; blink_delay = 0 ; nbdelay = 500 ; key = ALL_RELEASED  ;
                strcpy(org_pass , entered_pass);
                for(int i = 0  ;  i <= 4 ; i++ ){
                    ext_eeprom_24C02_byte_write(i , org_pass[i]  );
                }
                entered_pass[0] = ' ' ; entered_pass[1] = ' ' ;entered_pass[2] = ' ' ; entered_pass[3] = ' ' ;
                entered_pass[4] = ' ' ;
                clcd_print("Password Changed"  ,  LINE1(0));
                clcd_print("Successfully.   "  ,  LINE2(0));
                __delay_ms(2550);
                flag = 2 ;
                
            }
            
            if(!nbdelay--){
                nbdelay = 500 ;
                flag = 2 ;
                entered_pass[0] = ' ' ;
                entered_pass[1] = ' ' ;
                entered_pass[2] = ' ' ;
                entered_pass[3] = ' ' ;
                entered_pass[4] = ' ' ;
                blink_index = 0 ; blink_delay = 0 ;
            }
            
        }
        if(flag == 7){
            
            stkey = read_digital_keypad(LEVEL);
            
            if(blink_delay++ < 10){
                if(stblinkf == 0){
                    clcd_putch( (stsec/10)+'0' ,  LINE2(10));
                    clcd_putch( (stsec%10)+'0' ,  LINE2(11));
                }
                else if(stblinkf == 1){
                    clcd_putch( (stmin/10)+'0' ,  LINE2(7));
                    clcd_putch( (stmin%10)+'0' ,  LINE2(8));
                }
                else if(stblinkf == 2){
                    clcd_putch( (sthr/10)+'0'  ,  LINE2(4));
                    clcd_putch( (sthr%10)+'0'  ,  LINE2(5));
                }
                
                
            }else if(blink_delay < 20){
                if(stblinkf == 0){
                    clcd_putch(' ' ,  LINE2(10));
                    clcd_putch(' ' ,  LINE2(11));
                }
                else if(stblinkf == 1){
                    clcd_putch(' ' ,  LINE2(7));
                    clcd_putch(' ' ,  LINE2(8));
                }
                else if(stblinkf == 2){
                    clcd_putch(' ' ,  LINE2(4));
                    clcd_putch(' ' ,  LINE2(5));
                }
                
            }else{
                blink_delay = 0 ;
            }
            
            if(key == SW5){
                if(stblinkf == 0){
                    clcd_putch( (stsec/10)+'0' ,  LINE2(10));
                    clcd_putch( (stsec%10)+'0' ,  LINE2(11));
                }
                else if(stblinkf == 1){
                    clcd_putch( (stmin/10)+'0' ,  LINE2(7));
                    clcd_putch( (stmin%10)+'0' ,  LINE2(8));
                }
                else if(stblinkf == 2){
                    clcd_putch( (sthr/10)+'0'  ,  LINE2(4));
                    clcd_putch( (sthr%10)+'0'  ,  LINE2(5));
                }
                stblinkf++;
                if(stblinkf == 3) stblinkf = 0 ;
            }
            
            while(stkey == SW4){
                stkey = read_digital_keypad(LEVEL);
                stup = 1 ;
                if(stwait++ > 65000){
                    clcd_print("Change Time ?   " ,  LINE1(0));
                    clcd_print("Yes:UP / No:DOWN" ,  LINE2(0));
                    stwait = 0 ;
                    stup = 0 ;
                    flag = 10 ;
                    key = ALL_RELEASED ;
                    __delay_ms(3000) ;
                    break ;
                }
                if(stkey == ALL_RELEASED) stwait = 0 ;
                
            }
            if(stup == 1){
                stup = 0 ;
                stwait = 0 ;
                if(stblinkf == 0){
                    stsec++;
                    if(stsec == 60) stsec = 0 ;
                }else if(stblinkf == 1){
                    stmin++;
                    if(stmin == 60) stmin = 0 ;
                }else if(stblinkf == 2){
                    sthr++ ;
                    if(sthr == 24) sthr = 0 ;
                }
            }
            
            
            
        }
        if(flag == 10){
            
            
            if(key == SW5){
                flag = 2 ;
            }
            else if(key == SW4){
                set_time_custom(sthr ,  stmin , stsec  );
                clcd_print("Time changed    " , LINE1(0));
                clcd_print("Successfully.   " , LINE2(0));
                __delay_ms(2500);
                flag = 2 ;
            }
        }
        if(flag == 6){
            transmit_log();
            
            clcd_print("Log Downloaded  " ,  LINE1(0));
            clcd_print("Successfully.   " ,  LINE2(0));
            __delay_ms(2500);
            flag = 2 ;
        }
        
    }
    
}
