#include"main.h"


unsigned char time[6];

unsigned char log[11] ;
int pos =  0;
int event_count =  0;


void get_time(){
    time[0] = (((read_ds1307(HOUR_ADDR)) >> 4) & 0x03) + '0';
    time[1] = ((read_ds1307(HOUR_ADDR)) & 0x0F) + '0';
    
    
     
    time[2] = (((read_ds1307(MIN_ADDR)) >> 4) & 0x07) + '0';
    time[3] = ((read_ds1307(MIN_ADDR)) & 0x0F) + '0';
    
    
    
    time[4] = (((read_ds1307(SEC_ADDR)) >> 4) & 0x07) + '0';
    time[5] = ((read_ds1307(SEC_ADDR)) & 0x0F) + '0';
    
}

void display_time()
{
    
    get_time();
    
    clcd_putch( time[0]  ,  LINE2(0)   );
    clcd_putch( time[1]  ,  LINE2(1)   );
    clcd_putch( ':'  ,      LINE2(2)   );
    clcd_putch( time[2]  ,  LINE2(3)   );
    clcd_putch( time[3]  ,  LINE2(4)   );
    clcd_putch( ':'  ,      LINE2(5)   );
    clcd_putch( time[4]  ,  LINE2(6)   );
    clcd_putch( time[5]  ,  LINE2(7)   );
    
     
}

static void log_event()
{
    static char addr = 0x05;
    pos++ ;
    if(pos == 10)  pos = 0 ;
    ext_eeprom_24C02_byte_write(  105 ,  pos);
    addr  = pos * 10 + 5 ;
    ext_eeprom_24C02_str_write(addr, log);
    if(event_count <= 9) event_count ++ ;
    ext_eeprom_24C02_byte_write(  108 ,  event_count);
}

void log_car_event(unsigned char * event ,  unsigned char speed ){
    pos = ext_eeprom_24C02_read(105);
    event_count = ext_eeprom_24C02_read(108);
    get_time();
    strncpy(log , time , 6 );
    strncpy(&log[6], event , 2   );
    log[8] = speed / 10 + '0' ;
    log[9] = speed % 10 + '0' ;
    log[10] = 0 ;
    log_event();
}
void init_timer0(void)
{
    /* Setting the internal clock source */
    T0CS = 0;
    
    /* Assinging the prescaler to Timer0 */
    PSA = 0;
    
    /* Setting the scale to 1:16 */
    PS0 = 1;
    PS1 = 1;
    PS2 = 0;

    TMR0 = 6;
    
    /* The timer interrupt is enabled */
    TMR0IE = 1;
    TMR0IF = 0 ;
    GIE = 0 ;
}

void display_log(short int viewlogindex)
{
    unsigned char poss = ext_eeprom_24C02_read(105);
    
    clcd_putch(viewlogindex + '0'  ,  LINE2(0)  );
    clcd_putch(ext_eeprom_24C02_read( ((((poss)+1+viewlogindex)%10)*10+5)+0 ) ,  LINE2(2)   );
    clcd_putch(ext_eeprom_24C02_read( ((((poss)+1+viewlogindex)%10)*10+5)+1 ) ,  LINE2(3)   );
    
    clcd_putch(ext_eeprom_24C02_read( ((((poss)+1+viewlogindex)%10)*10+5)+2 ) ,  LINE2(5)   );
    clcd_putch(ext_eeprom_24C02_read( ((((poss)+1+viewlogindex)%10)*10+5)+3 ) ,  LINE2(6)   );
    
    clcd_putch(ext_eeprom_24C02_read( ((((poss)+1+viewlogindex)%10)*10+5)+4 ) ,  LINE2(8)   );
    clcd_putch(ext_eeprom_24C02_read( ((((poss)+1+viewlogindex)%10)*10+5)+5 ) ,  LINE2(9)   );
    clcd_putch(ext_eeprom_24C02_read( ((((poss)+1+viewlogindex)%10)*10+5)+6 ) ,  LINE2(11)   );
    clcd_putch(ext_eeprom_24C02_read( ((((poss)+1+viewlogindex)%10)*10+5)+7 ) ,  LINE2(12)   );
    clcd_putch(ext_eeprom_24C02_read( ((((poss)+1+viewlogindex)%10)*10+5)+8 ) ,  LINE2(14)   );
    clcd_putch(ext_eeprom_24C02_read( ((((poss)+1+viewlogindex)%10)*10+5)+9 ) ,  LINE2(15)   );
    
}

void set_time_custom(int sthr , int stmin , int stsec)
{
    int refhr = 0 ; int refmin = 0 ; int refsec = 0 ;
    
    unsigned char temp1 = read_ds1307(HOUR_ADDR);
    unsigned char temp2 = (temp1 & 0b11000000);
    
    unsigned char temp3 = (refhr/10) << 4 ;
    unsigned char temp4 = (refhr%10) ;
    unsigned char temp5 = temp3 | temp4 ;
    
    unsigned char hr = temp5 | temp2 ;
    
    temp1 = read_ds1307(MIN_ADDR);
    temp2 = (temp1 &  0b10000000   );
    temp3 = (refmin/10) << 4 ;
    temp4 = refmin%10 ;
    temp5 = temp3 | temp4 ;
    
    unsigned char min = temp5 | temp2 ;
    
    temp1 = read_ds1307(SEC_ADDR);
    temp2 = (temp1 &  0b10000000   );
    temp3 = (refsec/10) << 4 ;
    temp4 = refsec%10 ;
    temp5 = temp3 | temp4 ;
    
    unsigned char sec = temp5 | temp2 ;
    
    write_ds1307(HOUR_ADDR , hr);
    write_ds1307(MIN_ADDR , min);
    write_ds1307(SEC_ADDR , sec);
    
    
    temp1 = read_ds1307(HOUR_ADDR);
    temp2 = (temp1 & 0b11000000);
    temp3 = (sthr/10) << 4 ;
    temp4 = (sthr%10) ;
    temp5 = temp3 | temp4 ;
    
    hr = temp5 | temp2 ;
    
    temp1 = read_ds1307(MIN_ADDR);
    temp2 = (temp1 &  0b10000000   );
    temp3 = (stmin/10) << 4 ;
    temp4 = stmin%10 ;
    temp5 = temp3 | temp4 ;
    
    min = temp5 | temp2 ;
    
    temp1 = read_ds1307(SEC_ADDR);
    temp2 = (temp1 &  0b10000000   );
    temp3 = (stsec/10) << 4 ;
    temp4 = stsec%10 ;
    temp5 = temp3 | temp4 ;
    
    sec = temp5 | temp2 ;
    
    write_ds1307(HOUR_ADDR , hr);
    write_ds1307(MIN_ADDR , min);
    write_ds1307(SEC_ADDR , sec);
    
}

void transmit_log()
{
    unsigned char ev_count = ext_eeprom_24C02_read(108);
    unsigned char poss = ext_eeprom_24C02_read(105);
    
    unsigned char index = 9 ;
    
    
    puts("\n------------------------------------------------------------------\n\n");
    
    
    for(int i = 0 ;  i < ev_count ; i++ ){
        
        
        putchar(   index + '0' )  ;
        putchar(' ') ;
        putchar( ext_eeprom_24C02_read( ((((poss)+1+index)%10)*10+5)+ 0 )  );
        putchar( ext_eeprom_24C02_read( ((((poss)+1+index)%10)*10+5)+ 1 )  ) ;
        putchar(':') ;
        putchar( ext_eeprom_24C02_read( ((((poss)+1+index)%10)*10+5)+ 2 )  );
        putchar( ext_eeprom_24C02_read( ((((poss)+1+index)%10)*10+5)+ 3 )  );
        putchar( ':' ) ;
        putchar( ext_eeprom_24C02_read( ((((poss)+1+index)%10)*10+5)+ 4 ) ) ;
        putchar(ext_eeprom_24C02_read( ((((poss)+1+index)%10)*10+5)+ 5 )  );
        putchar(' ') ;
        putchar( ext_eeprom_24C02_read( ((((poss)+1+index)%10)*10+5)+ 6 ) ) ;
        putchar( ext_eeprom_24C02_read( ((((poss)+1+index)%10)*10+5)+ 7 ) ) ;
        putchar( ' ' ) ;
        putchar( ext_eeprom_24C02_read( ((((poss)+1+index)%10)*10+5)+ 8 ) );
        putchar( ext_eeprom_24C02_read( ((((poss)+1+index)%10)*10+5)+ 9 ) );
        putchar('\n');
        
        index--;
    }
    
    
    puts("\n------------------------------------------------------------------\n\n");
    
    /*
    for(int i = 0  ; i < ev_count ; i++ ){
        puts(array[i]);
        putchar('\n') ;
    }
    
    puts("\n------------------------------------------------------------------\n\n");
    */
}
