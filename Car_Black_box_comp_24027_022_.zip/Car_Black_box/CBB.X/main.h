

#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <string.h>
#include"clcd.h"
#include"i2c.h"
#include"ds1307.h"
#include"EEprom.h"
#include"digital_keypad.h"
#include"adc.h"
#include"uart.h"



void get_time();

void display_time(void);

void log_car_event(unsigned char * event ,  unsigned char speed );

void init_timer0(void);

void display_log(short int viewlogindex);

void set_time_custom(int sthr , int stmin , int stsec) ;

void transmit_log() ;

#endif	/* XC_HEADER_TEMPLATE_H */

