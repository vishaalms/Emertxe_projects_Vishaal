/*
 * File:   main.c
 * Author: Vishaal MS
 *
 * Created on 27 April, 2025, 7:10 PM
 */


#include <xc.h>
#include"EEprom.h"
#include"i2c.h"

#pragma config WDTE = OFF



void main(void) {
    init_i2c(100000);
    //password:
    ext_eeprom_24C02_byte_write(0 , '1');
    ext_eeprom_24C02_byte_write(1 , '1');
    ext_eeprom_24C02_byte_write(2 , '1');
    ext_eeprom_24C02_byte_write(3 , '1');
    ext_eeprom_24C02_byte_write(4 , '1');
    
    ext_eeprom_24C02_byte_write(105 ,  0 ); //pos variable
    ext_eeprom_24C02_byte_write(106 ,  0 ); //locked_flag
    ext_eeprom_24C02_byte_write(107 ,  3 ); //attempt_count
    ext_eeprom_24C02_byte_write(108 ,  0 ); //Event_count
    
    while(1) ;
    
    return;
}
